using UnityEngine;
using UnityEngine.UI;
using Clicker.Levels;
using Clicker.Content;

namespace Clicker.UI
{
    /// <summary>
    /// LevelUI for LevelManager without sublevels.
    /// Shows level number, progress bar and explanation when unlocked.
    /// </summary>
    public class LevelUI : MonoBehaviour
    {
        [Header("References")]
        public LevelManager levelManager;

        [Header("UI Elements")]
        public Text levelText;
        public Text sublevelText; // optional: we'll hide it when sublevels are not used
        public Image progressFill;
        public Text progressPercentText;

        [Header("Explanation Panel")]
        public GameObject explanationPanel;
        public Text explanationTitle;
        public Text explanationBody;

        [Header("Content")]
        public AdviceDatabase adviceDB;

        private void Start()
        {
            if (levelManager == null)
            {
                Debug.LogWarning("LevelUI: no LevelManager assigned.");
                return;
            }

            if (adviceDB == null)
            {
                adviceDB = Resources.Load<AdviceDatabase>("AdviceDB");
                if (adviceDB == null)
                {
                    Debug.LogWarning("LevelUI: AdviceDB not found in Resources/AdviceDB. Use Tools->Clicker->Create 15 Advice assets to generate placeholders.");
                }
            }

            // Hide sublevel text if present (no sublevels anymore)
            if (sublevelText != null) sublevelText.gameObject.SetActive(false);

            EnsureProgressFillSetup();

            levelManager.OnProgressChanged += OnProgressChanged;
            levelManager.OnExplanationUnlocked += OnExplanationUnlocked;
            levelManager.ForceRecalculate();
        }

        private void OnDestroy()
        {
            if (levelManager != null)
            {
                levelManager.OnProgressChanged -= OnProgressChanged;
                levelManager.OnExplanationUnlocked -= OnExplanationUnlocked;
            }
        }

        private void EnsureProgressFillSetup()
        {
            if (progressFill == null) return;

            progressFill.type = Image.Type.Filled;
            progressFill.fillMethod = Image.FillMethod.Horizontal;
            progressFill.fillOrigin = 0;
            progressFill.fillAmount = 0f;

            var rt = progressFill.GetComponent<RectTransform>();
            if (rt != null)
            {
                rt.anchorMin = new Vector2(0, 0);
                rt.anchorMax = new Vector2(1, 1);
                rt.offsetMin = Vector2.zero;
                rt.offsetMax = Vector2.zero;
            }
        }

        private void OnProgressChanged(int lvl, double frac, bool unlocked)
        {
            if (levelText != null) levelText.text = $"Совет {lvl}";
            if (progressFill != null) progressFill.fillAmount = (float)frac;
            if (progressPercentText != null) progressPercentText.text = $"{(int)(frac*100)}%";

            // Set explanation panel visibility according to unlocked flag.
            if (explanationPanel != null)
            {
                explanationPanel.SetActive(unlocked);
            }

            // Update texts if unlocked; otherwise clear them
            if (unlocked)
            {
                var adv = adviceDB != null ? adviceDB.GetAdvice(lvl) : null;
                if (adv != null)
                {
                    if (explanationTitle != null) explanationTitle.text = adv.title;
            // decide whether to show long explanation or short text based on LevelManager state
            bool _showLong = false;
            if (levelManager != null)
            {
                int advIndex = adv.index; // 1-based
                int current = levelManager.currentLevel; // 1-based
                if (current > advIndex) _showLong = true;
                else if (current == advIndex)
                    _showLong = levelManager.explanationUnlocked || levelManager.progressFraction >= 0.58;
            }
            if (explanationBody != null)
            {
                if (_showLong)
                    explanationBody.text = adv.longExplanation;
                else
                    explanationBody.text = !string.IsNullOrEmpty(adv.shortText) ? adv.shortText : (levelManager != null && levelManager.explanationUnlocked ? (adv.longExplanation ?? "") : "");
            }
                }
                else
                {
                    if (explanationTitle != null) explanationTitle.text = $"Объяснение {lvl}";
                    if (explanationBody != null) explanationBody.text = $"Здесь будет подробное объяснение для совета {lvl} (плейсхолдер).";
                }
            }
            else
            {
                if (explanationTitle != null) explanationTitle.text = "";
                if (explanationBody != null) explanationBody.text = "";
            }
        }

        private void OnExplanationUnlocked(int lvl)
        {
            if (adviceDB == null) adviceDB = Resources.Load<AdviceDatabase>("AdviceDB");

            var adv = adviceDB != null ? adviceDB.GetAdvice(lvl) : null;
            if (adv != null)
            {
                if (explanationTitle != null) explanationTitle.text = adv.title;
            // decide whether to show long explanation or short text based on LevelManager state
            bool _showLong = false;
            if (levelManager != null)
            {
                int advIndex = adv.index; // 1-based
                int current = levelManager.currentLevel; // 1-based
                if (current > advIndex) _showLong = true;
                else if (current == advIndex)
                    _showLong = levelManager.explanationUnlocked || levelManager.progressFraction >= 0.58;
            }
            if (explanationBody != null)
            {
                if (_showLong)
                    explanationBody.text = adv.longExplanation;
                else
                    explanationBody.text = !string.IsNullOrEmpty(adv.shortText) ? adv.shortText : (levelManager != null && levelManager.explanationUnlocked ? (adv.longExplanation ?? "") : "");
            }
            }
            else
            {
                if (explanationTitle != null) explanationTitle.text = $"Объяснение {lvl}";
                if (explanationBody != null) explanationBody.text = $"Здесь будет подробное объяснение для совета {lvl} (плейсхолдер).";
            }

            if (explanationPanel != null) explanationPanel.SetActive(true);
        }
    }
}
