using UnityEngine;
using UnityEngine.UI;
using Clicker.Content; // Advice класс в этом пространстве имён

/// <summary>
/// UI для одной записи Advice.
/// Исправление: shortText теперь показывается всегда, когда showLong == false (т.е. до достижения порога),
/// независимо от того, открыт ли заголовок. Заголовок по-прежнему зависит от unlockedTitle.
/// Добавлены дополнительные защиты и логирование для диагностики в консоли.
/// </summary>
public class AdviceEntryUI : MonoBehaviour
{
    public Text titleText;
    public Text explanationText;
    public GameObject lockOverlay; // отображается, если заголовок закрыт (по-прежнему используется для визуального оформления)

    /// <summary>
    /// Bind an Advice object.
    /// - advice: ScriptableObject Advice (использует поля index, title, shortText, longExplanation)
    /// - showLong: true -> показываем longExplanation; false -> показываем shortText (если есть)
    /// - unlockedTitle: true -> показываем реальный заголовок; false -> показываем "??"
    /// </summary>
    public void Bind(Advice advice, bool showLong, bool unlockedTitle)
    {
        string dbgAdviceId = advice != null ? $"Advice(index={advice.index}, title='{advice.title}')" : "null";
        string dbgShort = advice != null ? (advice.shortText ?? "<null>") : "<null>";
        int longLen = (advice != null && advice.longExplanation != null) ? advice.longExplanation.Length : 0;
        Debug.Log($"[AdviceEntryUI] Bind called for {dbgAdviceId} showLong={showLong} unlockedTitle={unlockedTitle} shortText='{dbgShort}' longLen={longLen}");

        if (advice == null)
        {
            if (titleText != null) titleText.text = "??";
            if (explanationText != null) explanationText.text = "";
            if (lockOverlay != null) lockOverlay.SetActive(true);
            return;
        }

        // Title: зависит только от unlockedTitle
        if (titleText != null)
            titleText.text = unlockedTitle ? advice.title : "??";

        // Explanation: shortText должен отображаться даже если заголовок закрыт,
        // как пользователь просил — пока showLong == false
        if (explanationText != null)
        {
            // Включаем объект и компонент если вдруг выключены
            if (!explanationText.gameObject.activeInHierarchy)
                explanationText.gameObject.SetActive(true);

            // Проверяем CanvasGroup в родителях — если он есть и полностью прозрачный, делаем видимым
            var cg = explanationText.GetComponentInParent<CanvasGroup>();
            if (cg != null && cg.alpha <= 0f)
                cg.alpha = 1f;

            // Если цвет текста полностью прозрачный — установим непрозрачный цвет (оставляя RGB)
            if (explanationText.color.a <= 0f)
            {
                var c = explanationText.color;
                c.a = 1f;
                explanationText.color = c;
            }

            // Отображение
            if (showLong)
            {
                explanationText.text = advice.longExplanation ?? "";
            }
            else
            {
                if (!string.IsNullOrEmpty(advice.shortText))
                {
                    explanationText.text = advice.shortText;
                }
                else
                {
                    // Если shortText пустой — показываем longExplanation только если заголовок открыт
                    explanationText.text = unlockedTitle ? (advice.longExplanation ?? "") : "";
                }
            }
        }
        else
        {
            Debug.LogWarning("[AdviceEntryUI] explanationText is not assigned on " + gameObject.name);
        }

        if (lockOverlay != null)
            lockOverlay.SetActive(!unlockedTitle);
    }
}
