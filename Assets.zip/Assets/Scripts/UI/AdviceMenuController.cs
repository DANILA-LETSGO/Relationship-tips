using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using Clicker.Content; // Advice
using Clicker.Levels;  // LevelManager

/// <summary>
/// AdviceMenuController — интеграция с реальным LevelManager API (Clicker.Levels.LevelManager).
/// Показывает shortText до достижения порога и longExplanation после (логика использует LevelManager.currentLevel, progressFraction и explanationUnlocked).
/// Подписывается на события LevelManager.OnProgressChanged и OnExplanationUnlocked для автоматического обновления UI.
/// </summary>
public class AdviceMenuController : MonoBehaviour
{
    [Header("Setup")]
    [Tooltip("If empty, Advice assets will be loaded from Resources/Advices")]
    public Advice[] adviceList;
    public GameObject entryPrefab;
    public Transform contentParent;
    public Button closeButton;

    [Header("Options")]
    public bool populateOnStart = true;
    public bool startClosed = true;
    [Tooltip("0..1 threshold after which the long explanation is shown when levelManager progress is used directly")]
    public double progressThreshold = 0.58;

    [Header("References")]
    public LevelManager levelManager;

    private List<GameObject> _spawned = new List<GameObject>();

    void Reset()
    {
        if (levelManager == null)
            levelManager = FindObjectOfType<LevelManager>();
    }

    void OnEnable()
    {
        if (levelManager != null)
        {
            levelManager.OnProgressChanged += OnLevelProgressChanged;
            levelManager.OnExplanationUnlocked += OnLevelExplanationUnlocked;
        }
    }

    void OnDisable()
    {
        if (levelManager != null)
        {
            levelManager.OnProgressChanged -= OnLevelProgressChanged;
            levelManager.OnExplanationUnlocked -= OnLevelExplanationUnlocked;
        }
    }

    void Start()
    {
        if ((adviceList == null || adviceList.Length == 0))
        {
            var arr = Resources.LoadAll<Advice>("Advices");
            if (arr != null && arr.Length > 0) adviceList = arr;
        }

        if (closeButton != null)
        {
            closeButton.onClick.RemoveAllListeners();
            closeButton.onClick.AddListener(CloseMenu);
        }

        if (populateOnStart) Populate();
        if (startClosed) gameObject.SetActive(false);
    }

    private void OnLevelProgressChanged(int levelIndexOneBased, double progressFraction, bool explanationUnlocked)
    {
        // Обновляем UI — проще всего пересоздать список (Populate). Для оптимизации можно обновлять только нужный элемент.
        Refresh();
    }

    private void OnLevelExplanationUnlocked(int levelIndexOneBased)
    {
        Refresh();
    }

    public void Populate()
    {
        Clear();
        if (adviceList == null || adviceList.Length == 0 || entryPrefab == null || contentParent == null) return;

        foreach (var adv in adviceList.OrderBy(a => a.index))
        {
            var go = Instantiate(entryPrefab, contentParent);
            var entry = go.GetComponent<AdviceEntryUI>();
            var holder = go.GetComponent<AdviceDataHolder>();
            if (holder != null) holder.data = adv;

            bool showLong = ShouldShowLongExplanation(adv);
            bool unlockedTitle = showLong;

            if (entry != null) entry.Bind(adv, showLong, unlockedTitle);
            _spawned.Add(go);
        }
    }

    public void Clear()
    {
        foreach (var g in _spawned) if (g != null) Destroy(g);
        _spawned.Clear();
    }

    /// <summary>
    /// long explanation is shown when:
    /// - levelManager.currentLevel > adv.index (we passed that level), or
    /// - levelManager.currentLevel == adv.index and (levelManager.explanationUnlocked || levelManager.progressFraction >= progressThreshold)
    /// </summary>
    public bool ShouldShowLongExplanation(Advice adv)
    {
        if (adv == null || levelManager == null) return false;

        int advIndex = adv.index; // 1-based
        int current = levelManager.currentLevel; // 1-based
        if (current > advIndex) return true;
        if (current < advIndex) return false;

        // current == advIndex
        if (levelManager.explanationUnlocked) return true;
        if (levelManager.progressFraction >= progressThreshold) return true;
        return false;
    }

    // API
    public void Refresh() { Populate(); }
    public void OpenMenu() { gameObject.SetActive(true); Populate(); }
    public void CloseMenu() { gameObject.SetActive(false); }
}
